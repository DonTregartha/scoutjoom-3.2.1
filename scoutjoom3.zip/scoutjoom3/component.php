	<?php
/**
 * @package     Joomla.Administrator
 * @subpackage  Templates.protostar
 *
 * @copyright   Copyright (C) 2005 - 2013 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;
require_once __DIR__ . '/functions/tpl-init.php';

JHtml::_('jquery.framework');
JHtml::_('bootstrap.framework');
JHtml::_('bootstrap.tooltip');

?>
<!DOCTYPE html>
<!--[if IE 8]><html class="no-js lt-ie9" lang="<?php echo $htmlLang; ?>" > <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" lang="<?php echo $htmlLang; ?>" > <!--<![endif]-->
	<head>
		<meta name="viewport" content="width=device-width, initial-scale=1">

		<!-- jQuery -->
		<?php if ($loadJquery == 1) : ?>
			<script src="<?php echo getDebugAssetUrl($tplUrl . '/js/jquery.min.js'); ?>" type="text/javascript"></script>
			<script src="<?php echo getDebugAssetUrl($tplUrl . '/js/jquery-noconflict.js'); ?>" type="text/javascript"></script>
			<script src="<?php echo getDebugAssetUrl($tplUrl . '/js/jquery-migrate.min.js'); ?>" type="text/javascript"></script>
		<?php elseif ($loadJquery == 2) : ?>
			<script src="//code.jquery.com/jquery-1.10.2.min.js"></script>
			<script src="//code.jquery.com/jquery-migrate-1.2.1.min.js"></script>
		<?php endif; ?>

		<?php if ($loadBootstrap == 1) : ?>
			<script src="<?php echo getDebugAssetUrl($tplUrl . '/js/bootstrap.min.js'); ?>" type="text/javascript"></script>
		<?php elseif ($loadBootstrap == 2) : ?>
			<script src="//netdna.bootstrapcdn.com/bootstrap/3.0.3/js/bootstrap.min.js"></script>
		<?php endif; ?>

		<!--[if lt IE 9]>
		<script src="<?php echo $tplUrl; ?>/js/html5shiv.js" type="text/javascript"></script>
		<script src="<?php echo $tplUrl; ?>/js/respond.min.js" type="text/javascript"></script>
	    <![endif]-->
		<script src="<?php echo $tplUrl; ?>/js/modernizr.custom.js" type="text/javascript"></script>

		<script src="<?php echo getDebugAssetUrl($tplUrl . '/js/combined.min.js'); ?>" type="text/javascript"></script>

		<?php if ($loadBootstrap == 1) : ?>
			<link rel="stylesheet" href="<?php echo getDebugAssetUrl($tplUrl . '/css/bootstrap.min.css'); ?>">
		<?php elseif ($loadBootstrap == 2) : ?>
			<link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.0.3/css/bootstrap.min.css">
		<?php endif; ?>

		<!-- Fontawesome -->
		<?php if ($this->params->get('fontawesomecss')) : ?>
			<link rel="stylesheet" href="<?php echo getDebugAssetUrl($tplUrl . '/css/font-awesome.min.css'); ?>">
		<?php endif; ?>

		<link rel="stylesheet" href="<?php echo getDebugAssetUrl($tplUrl . '/css/combined.min.css'); ?>" type="text/css" media="screen" />
		<link rel="stylesheet" href="<?php echo getDebugAssetUrl($tplUrl . '/css/animate.css'); ?>" type="text/css" media="screen" />
		<link href='//fonts.googleapis.com/css?family=Droid+Sans' rel='stylesheet' type='text/css'>

		<jdoc:include type="head" />
		<?php if (@filesize('templates/joostrap/css/custom.css') > 5): ?>
				<link rel="stylesheet" href="<?php echo $tplUrl; ?>/css/custom.css" type="text/css" media="screen" />
		<?php endif; ?>
	<style type="text/css">
		body {
			margin-top: 0;
		}
	</style>
</head>
<body>
	<div class="wrapper">
	<jdoc:include type="message" />
	<jdoc:include type="component" />
	</div>
</body>
</html>
