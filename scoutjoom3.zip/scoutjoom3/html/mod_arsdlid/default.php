<?php
/**
 * @package AkeebaReleaseSystem
 * @copyright Copyright (c)2010-2013 Nicholas K. Dionysopoulos
 * @license GNU General Public License version 3, or later
 * @version $Id$
 */

defined('_JEXEC') or die();

?>
<?php echo $params->get('pretext',''); ?>
<pre>
<?php echo $dlid; ?>
</pre>
<?php echo $params->get('posttext',''); ?>