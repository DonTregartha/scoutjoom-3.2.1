<?php
/**
 * @package AkeebaReleaseSystem
 * @copyright Copyright (c)2010-2013 Nicholas K. Dionysopoulos
 * @license GNU General Public License version 3, or later
 * @version $Id$
 */

defined('_JEXEC') or die();

?>
<?php echo $params->get('pretext',''); ?>

<table class="table table-striped">
<?php foreach($items as $i): ?>
	<tr>
		<td>
			<strong><?php echo htmlentities($i->name) ?></strong> <?php echo $i->version ?>
		</td>
		<td>
			<a class="btn btn-primary btn-sm" href="<?php echo JRoute::_('index.php?option=com_ars&view=download&format=raw&id='.$i->id) ?>">
				<span class="glyphicon glyphicon-download-alt"></span>
				Download
			</a>
		</td>
		<td>
			<a class="btn btn-default btn-sm" href="<?php echo JRoute::_('index.php?option=com_ars&view=release&id='.$i->release_id) ?>">
				<span>View all</span>
			</a>
		</td>
	</tr>
<?php endforeach; ?>
</table>

<?php echo $params->get('posttext',''); ?>