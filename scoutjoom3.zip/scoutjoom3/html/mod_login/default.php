<?php
/**
 * @package     Joomla.Site
 * @subpackage  mod_login
 *
 * @copyright   Copyright (C) 2005 - 2013 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

JHtml::_('behavior.keepalive');
JHtml::_('bootstrap.tooltip');

?>
<form action="<?php echo JRoute::_('index.php', true, $params->get('usesecure')); ?>" method="post" class="well well-sm form-inline" role="form">
	<div class="form-group">
		<label class="sr-only" for="modlogin-username">
			<?php echo JText::_('MOD_LOGIN_VALUE_USERNAME'); ?>
		</label>
		<div class="input-group">
			<span class="input-group-addon icon-user hasTooltip" title="<?php echo JText::_('MOD_LOGIN_VALUE_USERNAME') ?>"></span>
			<input id="modlogin-username" type="text" name="username" class="input-small" tabindex="0" size="18" placeholder="<?php echo JText::_('MOD_LOGIN_VALUE_USERNAME') ?>" />
		</div>
	</div>

	<div class="form-group">
		<label for="modlogin-passwd" class="sr-only">
			<?php echo JText::_('JGLOBAL_PASSWORD'); ?>
		</label>
		<div class="input-group">
			<span class="input-group-addon icon-lock hasTooltip" title="<?php echo JText::_('JGLOBAL_PASSWORD') ?>"></span>
			<input id="modlogin-passwd" type="password" name="password" class="input-small" tabindex="0" size="18" placeholder="<?php echo JText::_('JGLOBAL_PASSWORD') ?>" />
		</div>
	</div>

	<?php if (count($twofactormethods) > 1): ?>
	<div class="form-group">
		<label for="modlogin-secretkey" class="sr-only">
			<?php echo JText::_('JGLOBAL_SECRETKEY'); ?>
		</label>
		<div class="input-group">
			<span class="input-group-addon icon-star hasTooltip" title="<?php echo JText::_('JGLOBAL_SECRETKEY_HELP') ?>"></span>
			<input id="modlogin-secretkey" type="text" name="secretkey" class="input-small" tabindex="0" size="18" placeholder="<?php echo JText::_('JGLOBAL_SECRETKEY') ?>" />
		</div>
	</div>
	<?php endif; ?>

	<?php if (JPluginHelper::isEnabled('system', 'remember')) : ?>
		<span class="checkbox">
			<label>
				<input id="modlogin-remember" type="checkbox" name="remember" class="inputbox" value="yes"/>
				<?php echo JText::_('MOD_LOGIN_REMEMBER_ME') ?>
			</label>
		</span>
	<?php endif; ?>

	<button type="submit" tabindex="0" name="Submit" class="btn btn-primary">
		<?php echo JText::_('JLOGIN') ?>
	</button>

	<br/>

	<span>
		&nbsp;&nbsp;&nbsp;
		<a href="<?php echo JRoute::_('index.php?option=com_users&view=remind'); ?>"><?php echo JText::_('MOD_LOGIN_FORGOT_YOUR_USERNAME'); ?></a>
		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		<a href="<?php echo JRoute::_('index.php?option=com_users&view=reset'); ?>"><?php echo JText::_('MOD_LOGIN_FORGOT_YOUR_PASSWORD'); ?></a>
	</span>

	<input type="hidden" name="option" value="com_users" />
	<input type="hidden" name="task" value="user.login" />
	<input type="hidden" name="return" value="<?php echo $return; ?>" />
	<?php echo JHtml::_('form.token'); ?>
</form>