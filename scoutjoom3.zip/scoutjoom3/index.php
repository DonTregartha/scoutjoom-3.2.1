<?php
/**
 * @package     Joostrap.Template
 * @subpackage  Base
 *
 * @copyright   Copyright (C) 2005 - 2014 Joostrap. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */
defined('_JEXEC') or die;

require_once __DIR__ . '/functions/tpl-init.php';
?>
<!DOCTYPE html>
<!--[if IE 8]><html class="no-js lt-ie9" lang="<?php echo $htmlLang; ?>" > <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" lang="<?php echo $htmlLang; ?>" > <!--<![endif]-->
	<head>
		<meta name="viewport" content="width=device-width, initial-scale=1">

		<!-- jQuery -->
		<?php if ($loadJquery == 1) : ?>
			<script src="<?php echo getDebugAssetUrl($tplUrl . '/js/jquery.min.js'); ?>" type="text/javascript"></script>
			<script src="<?php echo getDebugAssetUrl($tplUrl . '/js/jquery-noconflict.js'); ?>" type="text/javascript"></script>
			<script src="<?php echo getDebugAssetUrl($tplUrl . '/js/jquery-migrate.min.js'); ?>" type="text/javascript"></script>
		<?php elseif ($loadJquery == 2) : ?>
			<script src="//code.jquery.com/jquery-1.10.2.min.js"></script>
			<script src="//code.jquery.com/jquery-migrate-1.2.1.min.js"></script>
		<?php endif; ?>

		<?php if ($loadBootstrap == 1) : ?>
			<script src="<?php echo getDebugAssetUrl($tplUrl . '/js/bootstrap.min.js'); ?>" type="text/javascript"></script>
		<?php elseif ($loadBootstrap == 2) : ?>
			<script src="//netdna.bootstrapcdn.com/bootstrap/3.0.3/js/bootstrap.min.js"></script>
		<?php endif; ?>

		<!--[if lt IE 9]>
		<script src="<?php echo $tplUrl; ?>/js/html5shiv.js" type="text/javascript"></script>
		<script src="<?php echo $tplUrl; ?>/js/respond.min.js" type="text/javascript"></script>
	    <![endif]-->

		<script src="<?php echo $tplUrl; ?>/js/extras.js" type="text/javascript"></script>

		<?php if ($loadBootstrap == 1) : ?>
			<link rel="stylesheet" href="<?php echo getDebugAssetUrl($tplUrl . '/css/bootstrap.min.css'); ?>">
		<?php elseif ($loadBootstrap == 2) : ?>
			<link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.0.3/css/bootstrap.min.css">
		<?php endif; ?>

		<!-- Fontawesome -->
		<?php if ($this->params->get('fontawesomecss')) : ?>
			<link rel="stylesheet" href="<?php echo getDebugAssetUrl($tplUrl . '/css/font-awesome.min.css'); ?>">
		<?php endif; ?>

		<link rel="stylesheet" href="<?php echo getDebugAssetUrl($tplUrl . '/css/template.css'); ?>" type="text/css" media="screen" />
		<link rel="stylesheet" href="<?php echo getDebugAssetUrl($tplUrl . '/css/responsive.css'); ?>" type="text/css" media="screen" />
		<link rel="stylesheet" href="<?php echo getDebugAssetUrl($tplUrl . '/css/animate.css'); ?>" type="text/css" media="screen" />
		<link href='//fonts.googleapis.com/css?family=Droid+Sans' rel='stylesheet' type='text/css'>
		<?php
		if($lang->isRTL()) {
			$doc->addStyleSheet(JURI::base() . '/templates/' . $this->template . '/css/template-rtl.css');
			if ($template_responsive) {
				$doc->addStyleSheet(JURI::base() . 'templates/' . $this->template . '/css/template-responsive-rtl.css');
			}
		}
		$doc->addStyleSheet(JURI::base() . 'templates/' . $this->template . '/css/style' . $color_style . '.css');
	?>
		<jdoc:include type="head" />
		<?php if (@filesize('templates/joostrap/css/custom.css') > 5): ?>
				<link rel="stylesheet" href="<?php echo $tplUrl; ?>/css/custom.css" type="text/css" media="screen" />
		<?php endif; ?>
		<?php if ($this->params->get('wireframing')) : ?>
			<!-- Wireframing CSS -->
			<link rel="stylesheet" href="<?php echo getDebugAssetUrl($tplUrl . '/css/wireframing.css'); ?>">
		<?php endif; ?>
		<?php if (null !== $customColorsCss) : ?>
			<style type="text/css" charset="utf-8">
				<?php echo $customColorsCss; ?>
			</style>
		<?php endif; ?>
	<body class="<?php echo $option. " view-" .$view. " " .$frontpage. " itemid-" .$itemid. $rtl_detection; ?>">
	<div class="body-wrapper">
	<div id="sb-site">
		<header id="header">
			<div class="container">
			
				<div id="top-toolbar" class="pull-right">
					<div class="pull-right">
						<?php if ($this->countModules('search')) : ?>
							<jdoc:include type="modules" name="search" style="standard" />
						<?php endif; ?>
						<?php if ($social_icons) : ?>
							<ul class="social-icons pull-left hidden-xs">	
								<?php if( $twitter != '' ) : ?>
									<li class="icon_twitter"><a href="<?php echo $twitter; ?>" target="_blank"></a></li>
								<?php endif; ?>
								<?php if( $facebook != '' ) : ?>
									<li class="icon_facebook"><a href="<?php echo $facebook; ?>" target="_blank"></a></li> 
								<?php endif; ?>
								<?php if( $linkedin != '' ) : ?>
									<li class="icon_in"><a href="<?php echo $linkedin; ?>" target="_blank"></a></li> 
								<?php endif; ?>
								<?php if( $google_plus != '' ) : ?>
									<li class="icon_googleplus"><a href="<?php echo $google_plus; ?>" target="_blank"></a></li> 
								<?php endif; ?>
								<?php if( $pinterest != '' ) : ?>
									<li class="icon_pinterest"><a href="<?php echo $pinterest; ?>" target="_blank"></a></li> 
								<?php endif; ?>
								<?php if( $dribbble != '' ) : ?>
									<li class="icon_dribbble"><a href="<?php echo $dribbble; ?>" target="_blank"></a></li> 
								<?php endif; ?>
								<?php if( $flickr != '' ) : ?>
									<li class="icon_flickr"><a href="<?php echo $flickr; ?>" target="_blank"></a></li> 
								<?php endif; ?>
								<?php if( $youtube != '' ) : ?>
									<li class="icon_youtube"><a href="<?php echo $youtube; ?>" target="_blank"></a></li> 
								<?php endif; ?>
								<?php if( $vimeo != '' ) : ?>
									<li class="icon_vimeo"><a href="<?php echo $vimeo; ?>" target="_blank"></a></li> 
								<?php endif; ?>
							</ul>
						<?php endif; ?>
					</div>
				</div>
			
				<div class="logo pull-left">
					<jdoc:include type="modules" name="logo" style="standard" />
				</div>
				<div type="button" class="navbar-btn pull-right" data-toggle="collapse" data-target=".navbar-collapse">
					<div class="sb-toggle-left">
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					</div>
				</div>
			</div>
		</header>
	<?php if ($this->countModules('menu')): ?>
		<nav id="menu" class="clearfix hidden-xs">	
			<div class="container">
				<div class="navbar-collapse collapse">
					<jdoc:include type="modules" name="menu" style="basic" />
				</div>	
			</div>
		</nav>
	<?php endif; ?>
	<?php if ($this->countModules('slideshow')): ?>	
		<div id="slider">	
				<jdoc:include type="modules" name="slideshow" style="standard" />
		</div>
	<?php endif; ?>	
	<?php if ($this->countModules('header')): ?>	
		<div id="top" class="clearfix">	
			<div class="container">
				<jdoc:include type="modules" name="header" style="standard" />
			</div>
		</div>
	<?php endif; ?>	
	<?php if ($this->countModules('breadcrumbs')): ?>
		<div id="breadcrumbs">
			<div class="container">
				<jdoc:include type="modules" name="breadcrumbs" style="standard" />
			</div>
		</div>
	<?php endif; ?>
	<?php if ($this->countModules('top')): ?>	
		<div id="top" class="clearfix">	
			<div class="container">
				<jdoc:include type="modules" name="top" style="standard" />
			</div>
		</div>
	<?php endif; ?>		
		<!-- Mainbody -->
		<div id="mainbody" class="clearfix">
			<div class="container">
				<div class="row">					
				<?php if ($this->countModules('left')): ?>
					<div class="sidebar-left col-md-<?php echo $left; ?>">
						<div class="sidebar-nav">
							<jdoc:include type="modules" name="left" style="standard" />
						</div>
					</div>
				<?php endif; ?>						
					<!-- Content Block -->
					<div id="content" class="col-md-<?php echo $span;?>">				
						<div id="message-component">
							<jdoc:include type="message" />
						</div>					
					<?php if ($this->countModules('above-content')): ?>
						<div id="above-content">
							<jdoc:include type="modules" name="above-content" style="standard" />
						</div>
					<?php endif; ?>					
					<?php
						$app = JFactory::getApplication();
						$menu = $app->getMenu();
								
							if ($frontpageshow){ 
							// show on all pages
							?>
							<div id="content-area">
								<jdoc:include type="component" />
							</div>
							<?php 
								}
								else {
								  if ($menu->getActive() !== $menu->getDefault()) {
								  // show on all pages but the default page
									?>
									<div id="content-area">
										<jdoc:include type="component" />
									</div>
							<?php
								    } 
								}
							?>		
					<?php if ($this->countModules('below-content')): ?>
						<div id="below-content">
							<jdoc:include type="modules" name="below-content" style="standard" />
						</div>
					<?php endif; ?>							
					</div>
					<?php if ($this->countModules('right')) : ?>
					<aside class="sidebar-right col-md-<?php echo $right; ?>">
						<jdoc:include type="modules" name="right" style="standard" />
					</aside>
					<?php endif; ?>			
				</div>
			</div>
		</div>
	<?php if ($this->countModules('bottom')): ?>
		<div id="bottom1" class="clearfix">
			<div class="container">
				<jdoc:include type="modules" name="bottom" style="standard" />
			</div>
		</div>
	<?php endif; ?>
	<?php if ($this->countModules('footer')): ?>
		<div id="bottom2" class="clearfix">
			<div class="container">
				<jdoc:include type="modules" name="footer" style="standard" />
			</div>
		</div>
	<?php endif; ?>
		<footer id="footer" class="clearfix">
			<div class="container">		
				<div style="float: left;">
				<?php if ($copyrights) : ?>
					<?php echo $copytext ?>
				<?php  else : ?>
					<a href="<?php echo $this->baseurl ?>"> <?php echo $sitename; ?></a> <?php echo date('Y');?>
				<?php endif; ?>				
			</div>		
			</div>
			<?php if ($totop) : ?>
					<a href="#" class="go-top">Back to Top <i class="fa fa-arrow-circle-up"></i></a>
					<?php endif; ?>
		</footer>	
	</div>
	</div>
	<div class="sb-slidebar sb-left"><!-- left Slidebar content. -->
			<h2>
				<?php if ($icon1) : ?>
				<a href="<?php echo $this->baseurl ?>"><i class="<?php echo $icon1; ?>"></i></a>&nbsp;&nbsp;&nbsp;
				<?php endif; ?>
				<?php if ($icon2) : ?>
				<a href="<?php echo $icon2url; ?>"><i class="<?php echo $icon2; ?>"></i></a>&nbsp;&nbsp;&nbsp;
				<?php endif; ?>
				<?php if ($icon3) : ?>
				<a href="<?php echo $icon3url; ?>"><i class="<?php echo $icon3; ?>"></i></a>&nbsp;&nbsp;&nbsp;
				<?php endif; ?>
				<?php if ($icon4) : ?>
				<a href="<?php echo $icon4url; ?>"><i class="<?php echo $icon4; ?>"></i></a>&nbsp;&nbsp;&nbsp;
				<?php endif; ?>
				<?php if ($icon5) : ?>
				<a href="<?php echo $icon5url; ?>"><i class="<?php echo $icon5; ?>"></i></a>&nbsp;&nbsp;&nbsp;
				<?php endif; ?>
				<?php if ($icon6) : ?>
				<a href="#"><i class="<?php echo $icon6; ?>"></i></a>
				<?php endif; ?>
			</h2>
			<?php if ($this->countModules('mob-menu-above')): ?>
			<div class="mob-menu-above">
				<jdoc:include type="modules" name="mob-menu-above" style="standard" />
			</div>
			<?php endif; ?>
			<?php if ($this->countModules('menu')): ?>
			<div class="mob-menu">
				<jdoc:include type="modules" name="menu" style="none" />
			</div>
			<?php endif; ?>
			<?php if ($this->countModules('mob-menu-below')): ?>
			<div class="mob-menu-below">
				<jdoc:include type="modules" name="mob-menu-below" style="standard" />
			</div>
			<?php endif; ?>
	</div>
	<jdoc:include type="modules" name="debug" style="none" />
	<script src="<?php echo $this->baseurl ?>/templates/<?php echo $this->template ?>/js/slidebars.min.js" type="text/javascript"></script>
	<script>
      (function($) {
        $(document).ready(function() {
          $.slidebars();
        });
      }) (jQuery);
    </script>
	<!-- Joostrap v3.1.2 -->
</body>
</html>
